﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.ImageEffects;

[ExecuteInEditMode]
public class ToneRampMapScript : ImageEffectBase
{
    public Texture2D _ramp;

    public void Reset()
    {
        shader = Shader.Find("Hidden/ToneRampMap");
    }

    void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        //マテリアル経由でシェーダーに値を渡す
        material.SetTexture("_Ramp", _ramp);
        Graphics.Blit(source, destination, material);
    }
}
