﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.ImageEffects;

[ExecuteInEditMode]
public class DesaturateScript : ImageEffectBase
{
    public float m_Chroma;

    public void Reset()
    {
        //スクリプトをアタッチした瞬間にシェーダープログラムが設定される
        shader = Shader.Find("Hidden/Desaturate");
    }

    void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        //マテリアル経由でシェーダーに値を渡す
        material.SetFloat("_Chroma", m_Chroma);
        Graphics.Blit(source, destination, material);
    }

    public void SetChroma()
    {
        if (m_Chroma < 0) return; 
        m_Chroma -= 0.1f;
    }
}
