﻿using UnityEngine;
using System.Collections;

public class CameraMove : MonoBehaviour
{
    //プレイヤー
    private GameObject _player;
    //最初の座標
    private Vector3 _startPosition;
    //自分の座標
    private Vector3 _toPosition;
    //最初のy座標
    private float _startY;
    //動き始めるかどうか
    public bool _moveFrag;

    void Start()
    {
        _moveFrag = false;
        //自分の座標を取得
        _toPosition = transform.position;
    }

    void LateUpdate()
    {
        //プレイヤーの座標が取得できない、または動くフラグがたってなかったら何もしない
        if (_player == null || _moveFrag == false) return;
       
        //移動座標の計算
        _toPosition.x = _player.transform.position.x + _startPosition.x;
        _toPosition.z = _player.transform.position.z + _startPosition.z;
        //座標を移動させる
        transform.position = new Vector3(_toPosition.x, _startY, _toPosition.z);
    }

    /// <summary>
    /// 追いかけ始める
    /// </summary>
    public void MoveStart()
    {
        //プレイヤーを取得
        _player = GameObject.FindGameObjectWithTag("Player");
        //最初の座標を取得
        _startPosition = transform.position - _player.transform.position;
        //y座標を取得
        _startY = transform.position.y;
        //動き始める
        _moveFrag = true;
    }
}
