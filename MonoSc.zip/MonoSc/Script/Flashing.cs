﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Flashing : MonoBehaviour
{
    private RectTransform _myRect;
    [SerializeField]
    private string _nextScene;
    [SerializeField]
    private GameObject _fadeEffe;
	// Use this for initialization
	void Start ()
    {
        _myRect = this.GetComponent<RectTransform>();
        //点滅を繰り返す
        LeanTween.alpha(_myRect, 0, 2)
            .setEase(LeanTweenType.easeInCubic)
            .setLoopPingPong();	
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            //シーンを移動させる
            _fadeEffe.GetComponent<FadeEffe>().SceneOut(_nextScene);
        }	
	}
}
