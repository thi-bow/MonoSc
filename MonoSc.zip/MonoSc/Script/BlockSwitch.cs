﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockSwitch : MonoBehaviour
{
    [SerializeField]
    private GameObject _block;
    private Rigidbody _freezeY;

	// Use this for initialization
	void Start ()
    {
        _freezeY = _block.GetComponent<Rigidbody>();
        //回転と座標移動を固定する
        _freezeY.constraints = RigidbodyConstraints.FreezeAll;
    }

    void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Player")
        {
            //ポジションYだけを固定解除させる
            _freezeY.constraints = RigidbodyConstraints.FreezeRotation  |
                                   RigidbodyConstraints.FreezePositionX |
                                   RigidbodyConstraints.FreezePositionZ;
        }
    }
}
