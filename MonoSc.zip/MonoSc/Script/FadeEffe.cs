﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class FadeEffe : MonoBehaviour
{
    //横の数
    [SerializeField]
    private int number;
    //縦の数
    [SerializeField]
    private int height;
    //表示する画像を取得
    [SerializeField]
    private RectTransform _imgBlack;
    //生成した画像を入れる(実行確認のためにInspectorに表示)
    [SerializeField]
    private List<RectTransform> _myList = new List<RectTransform>();
    //画像の番号
    private int _imgNumber;
    //待機時間
    private float _time;
    //シーンを移動中かどうか
    private bool _changeFrag;
    void Awake()
    {
        _changeFrag = true;
        _imgNumber = 0;
        //最初に画面を黒くする
        for(int i = 0; i <= number; i++)
        {
            for (int j = 0; j <= height; j++)
            {
                RectTransform child = Instantiate(_imgBlack);
                child.transform.SetParent(this.transform);
                child.transform.localScale = new Vector3(1, 1, 1);
                child.transform.localPosition = new Vector3(i * 50, j * -50, 0);
                _myList.Add(child);
                child = Instantiate(_imgBlack);
                child.transform.SetParent(this.transform);
                child.transform.localScale = new Vector3(1, 1, 1);
                child.transform.localPosition = new Vector3(i * -50, j * -50, 0);
                _myList.Add(child);
            }
        }
        if (SceneManager.GetActiveScene().name == "Title") _time = 0;
        else _time = 0;
    }

	// Use this for initialization
	void Start ()
    {
        StartCoroutine(EnabledOff(_time));
    }

    public void SceneOut(string name)
    {
        if (_changeFrag == true) return;
        StartCoroutine(EnabledOn(name));
    }
	
	
    //徐々に画面を見えるようにしていく
    IEnumerator EnabledOff(float time)
    {
        for (int i = 0; i <= number; i++)
        {
            for (int j = 0; j <= height; j++)
            {
                _myList[_imgNumber].GetComponent<Image>().enabled = false;
                yield return new WaitForSeconds(time);
                _imgNumber++;
                _myList[_imgNumber].GetComponent<Image>().enabled = false;
                _imgNumber++;
                yield return new WaitForSeconds(time);
            }
        }
        _changeFrag = false;
    }

    //徐々に画面を見えないようにしていき、最後にシーンを移動させる
    public IEnumerator EnabledOn(string name)
    {
        SoundManger.Instance.PlaySE(1);
        _changeFrag = true;
        for (int i = 0; i <= number; i++)
        {
            for (int j = 0; j <= height; j++)
            {
                _imgNumber--;
                _myList[_imgNumber].GetComponent<Image>().enabled = true;
                yield return new WaitForSeconds(0.0001f);
                _imgNumber--;
                _myList[_imgNumber].GetComponent<Image>().enabled = true;
                yield return new WaitForSeconds(0.0001f);
            }
        }
        SceneManagerScript.sceneManager.SceneOut(name);
    }
}
