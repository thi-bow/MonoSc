﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Player : MonoBehaviour
{

    //移動する方向ベクトル
    private Vector3 moveDirection = Vector3.zero;
    private float _starSpeed = 0;
    //移動速度
    [SerializeField]
    private float _speed;
    //ジャンプの高さ
    [SerializeField]
    private float _jump = 1.0f;
    //ジャンプフラグ
    private bool _jumpfrag = false;
    //CharacterController取得
    private CharacterController controller;
    //アニメータを取得
    private Animator _anime;
    //メインカメラ
    private GameObject _camera;
    //ゲームマネージャー
    [SerializeField]
    private GameObject _gameManager;

    //ゲームが始まったかどうか
    private bool _start;
    //ゲームが始まった時のロゴ
    [SerializeField]
    private GameObject _startLogo;
    //消滅時のパーティクル
    [SerializeField]
    private GameObject _deadParticle;

    // Use this for initialization
    void Start()
    {
        controller = GetComponent<CharacterController>();
        _camera = GameObject.Find("Main Camera");
        _anime = GetComponent<Animator>();
        _anime.SetBool("Jump", false);
        _anime.SetBool("Sliding", false);
        _jumpfrag = false;
        _start = false;
    }

    // Update is called once per frame
    void Update()
    {
        Move(9.8f);
    }

    //移動処理
    void Move(float gravity)
    {
        if (_jumpfrag == true) moveDirection.y = 0.0f;
        float y = moveDirection.y;

        var cameraForward = Vector3.Scale(_camera.transform.forward, new Vector3(1, 0, 1)).normalized;
        moveDirection = _camera.transform.right * _starSpeed;
        //地面についているか判定 && ゲームが始まっているかどうか
        if (_jumpfrag == true && _start == true)
        {
            if (Input.GetKeyDown(KeyCode.Z))
            {
                _jumpfrag = false;
                moveDirection.y = _jump; //ジャンプするベクトルの代入
                _anime.SetBool("Jump",true);
                StartCoroutine(JumpEnd());
            }

            if(Input.GetKeyDown(KeyCode.X))
            {
                //スライディング中はあたり判定を変更
                controller.center = new Vector3(0, 0.01f, 0);
                controller.radius = 0.01f;
                controller.height = 0.01f;
                _jumpfrag = false;
                _anime.SetBool("Sliding", true);
                //一定時間後スライディングを止める
                StartCoroutine(SlidingEnd());
            }
        }
        moveDirection.y += y;
        moveDirection.y -= gravity * Time.deltaTime;

        controller.Move(moveDirection * Time.deltaTime);
    }

    //当たり判定
    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if (hit.gameObject.tag == "Floor" && _jumpfrag == false)
        {
            _starSpeed = _speed;
            _anime.SetBool("Jump", false);
        }

        if (hit.gameObject.tag == "Damage")
        {
            SoundManger.Instance.PlaySE(4);
            SceneManagerScript.sceneManager.TimeSet(1.0f);
            _gameManager.GetComponent<GameManager>().ResultActive();
            Instantiate(_deadParticle, this.transform.localPosition, new Quaternion(0, 0, 0, 0));
            Destroy(this.gameObject);
        }
        
    }

    //当たり判定(Trigger)
    public void OnTriggerEnter(Collider col)
    {
        ///ゲーム開始
        if (col.gameObject.tag == "Start")
        {
            _camera.GetComponent<CameraMove>().MoveStart();
            _startLogo.GetComponent<StartLogo>().Move();
            _start = true;
            _jumpfrag = true;
        }
        //ステージの生成
        if(col.gameObject.tag == "StageIns")
        {
            _camera.GetComponent<DesaturateScript>().SetChroma();
            _gameManager.GetComponent<GameManager>().StageIns();
            Destroy(col.gameObject.transform.parent.gameObject, 2.0f);
        }
        //コインの取得
        if(col.gameObject.tag == "Coin")
        {
            _gameManager.GetComponent<GameManager>().CoinGet();
            Destroy(col.gameObject);
        }
    }

    //離れた時
    void OnCollisionExit(Collision other)
    {
        if(other.gameObject.tag == "Floor")
        {
            print("hoge");
            _jumpfrag = false;
        }
    }

    //ジャンプアニメーションが終了時
    public IEnumerator JumpEnd()
    {
        yield return new WaitForSeconds(1.0f);
        _jumpfrag = true;
    }

    //スライディングアニメーションが終了時
    public IEnumerator SlidingEnd()
    {
        yield return new WaitForSeconds(1.1f);
        _anime.SetBool("Sliding", false);
        controller.center = new Vector3(0, 0.1f, 0);
        controller.radius = 0.05f;
        controller.height = 0.2f;
        _jumpfrag = true;
    }

}