﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    //出てくるステージ
    [SerializeField]
    private GameObject[] _stage;
    //ステージの親にする
    [SerializeField]
    private GameObject _parent;
    //ステージを何個生成したか数える
    private int _stageNumber;
    //ゲームの時間
    private float _timeSpeed;
    //何枚のコインを取ったか数える
    private int _coinScore;
    //リザルトで出すUI
    [SerializeField]
    private GameObject _resultUI;

    // Use this for initialization
    void Start ()
    {
        _stageNumber = 0;
        _timeSpeed = 1.0f;
        _coinScore = 0;
    }
    public void StageIns()
    {
        _stageNumber++;
        //時間を徐々に速くしていく
        _timeSpeed += 0.05f;
        _timeSpeed = Mathf.Clamp(_timeSpeed, 1, 2.0f);
        int _rand = Random.Range(0, _stage.Length);
        //ステージを生成
        GameObject child = Instantiate(_stage[_rand], new Vector3(_stageNumber*11 + 44, 1, 0), new Quaternion(0, 0, 0, 0));
        //親を設定
        child.transform.SetParent(_parent.transform);
        //画面を隠す壁を生成
        child.GetComponent<CoinSet>().Hindrance(_stageNumber);
        //設定した時間を入れる
        SceneManagerScript.sceneManager.TimeSet(_timeSpeed);
    }

    public void CoinGet()
    {
        _coinScore++;
    }

    public int Coin()
    {
        return _coinScore;
    }

    public void ResultActive()
    {
        StartCoroutine(Result());
    }
    public IEnumerator Result()
    {
        //UI表示まで少し時間を置く
        yield return new WaitForSeconds(1);
        _resultUI.SetActive(true);
    }
}
