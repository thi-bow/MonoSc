﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ResultCount : MonoBehaviour
{
    private Text _text;
    //スコアを取得
    [SerializeField]
    private GameObject _score;
    //ゲームマネージャーを取得
    [SerializeField]
    private GameObject _gameManager;
    private int _count;
    private int _coin;
    private int _provisional;
    private bool _end;
    private float _time;

    private RectTransform _myRect;
    private bool _moveFrag;

    [SerializeField]
    private bool _coinCount;
    [SerializeField, TooltipAttribute("総合スコアならば入れる")]
    private GameObject _spaceTitle;

	// Use this for initialization
	void Start ()
    {
        _text = this.GetComponent<Text>();
        //スコアを取得
        _count = _score.GetComponent<MoveCount>().Count();
        //コイン数を取得
        _coin = _gameManager.GetComponent<GameManager>().Coin();
        //最終結果を計算
        _provisional = _count + (_coin * 10);
        _end = false;
        _time = 0;
        _myRect = this.GetComponent<RectTransform>();
        _moveFrag = false;
        SetText();
    }
	
	// Update is called once per frame
	void Update ()
    {
        //スコアのカウントが終わったら真ん中へ移動
        if(_end == true && _moveFrag == false)
        {
            MoveCenter();
            _spaceTitle.SetActive(true);
            _moveFrag = true;
        }

        _time += Time.deltaTime;
        if (_end == true || _time <= 0.5f) return;
        //何かボタンを押したら最終結果を表示させる
        if (Input.anyKeyDown)
        {
            if (_coinCount == false) _text.text = _provisional.ToString();
            else _text.text = _coin.ToString();
            _end = true;
            return;
        }
        //何もボタンを押さないで、スコアを足し終わったら
        if (_coin <= 0)
        {
            _end = true;
            return;
        }
        CoinAdd();
        SetText();
    }

    void CoinAdd()
    {
        SoundManger.Instance.PlaySE(0);
        //コイン数を減らす
        _coin--;
        //コイン1枚つきスコアを10足す
        _count += 10;
    }

    //中心へ移動
    void MoveCenter()
    {
        if (_coinCount == false) LeanTween.move(_myRect, new Vector2(0, 0), 1);
        else Destroy(this.gameObject);
    }

    //テキストに書き込む
    void SetText()
    {
        if (_coinCount == false) _text.text = _count.ToString();
        else _text.text = _coin.ToString();
    }
}
