﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinSet : MonoBehaviour
{
    [SerializeField]
    private GameObject[] _coin;
    [SerializeField]
    private GameObject _hindrance;
    // Use this for initialization
    void Start()
    {
        //コインをRandomで消す
        int _coinRand = 0;
        for(int i = 0; i < _coin.Length; i++)
        {
            _coinRand = Random.Range(0, 2);
            if (_coinRand == 0) _coin[i].SetActive(false);
        }
    }

    //黒い邪魔者を出す(先に行けば行くほどでる確率が増える)
    public void Hindrance(int number)
    {
        if (_hindrance == null) return;
        if (10 >= number) return;
        int _ins = Random.Range(0, 11);
        _ins = number - _ins;
        if (10 >= _ins) return;
        _ins = _ins % 2;
        if (_ins != 0) _hindrance.SetActive(true);
    }
}
