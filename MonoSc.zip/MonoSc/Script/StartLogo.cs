﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StartLogo : MonoBehaviour
{
    private RectTransform _muRect;

	// Use this for initialization
	void Start ()
    {
        _muRect = this.GetComponent<RectTransform>();	
	}

    public void Move()
    {
        //画面の中心に移動
        LeanTween.move(_muRect, new Vector2(0, 0), 0.5f)
            .setOnComplete(() =>
            {
                LeanTween.scale(_muRect, new Vector2(0, 0), 0.2f)
                .setDelay(0.5f);
            });
    }
}
