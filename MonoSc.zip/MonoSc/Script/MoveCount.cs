﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MoveCount : MonoBehaviour
{
    private GameObject _player;
    private float _startCount;
    private int _count;
    private Text _myText;

	// Use this for initialization
	void Start ()
    {
        _player = GameObject.Find("Player");
        _startCount = _player.transform.localPosition.x;
        _myText = this.GetComponent<Text>();
	}
	
	// Update is called once per frame
	void Update ()
    {
        //プレイヤーを取得できなかったら何もしない
        if (_player == null)
        {
            _myText.text = _count.ToString();
            return;
        }
        //最初の座標から進んだ距離を求める
        _count = (int)_player.transform.localPosition.x - (int)_startCount;
        _myText.text = _count.ToString();
	}

    public int Count()
    {
        return _count;
    }
}
