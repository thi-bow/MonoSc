﻿using UnityEngine;
using System.Collections;

public class Coin : MonoBehaviour
{

    [SerializeField]
    private float _speed;
    private float _angle;
    [SerializeField]
    private GameObject _particle;

    // Use this for initialization
    void Start()
    {
        _angle = 90.0f;
    }

    // Update is called once per frame
    void Update()
    {
        _angle += Time.deltaTime * _speed;
        this.transform.rotation = Quaternion.Euler(0, _angle, 90);
    }

    public void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            Dead();
        }
    }

    public void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag == "Player")
        {
            Dead();
        }
    }

    public void Dead()
    {
        //SEを流す
        SoundManger.Instance.PlaySE(3);
        //消滅時に自分の座標を取得
        Vector3 pos = this.GetComponent<Transform>().localPosition;
        //エフェクトを生成
        GameObject coin_effect = Instantiate(_particle, new Vector3(pos.x, pos.y, pos.z), Quaternion.Euler(-90, 0, 0));
        coin_effect.transform.SetParent(this.transform.parent);
        coin_effect.transform.localPosition = pos;
    }
}
